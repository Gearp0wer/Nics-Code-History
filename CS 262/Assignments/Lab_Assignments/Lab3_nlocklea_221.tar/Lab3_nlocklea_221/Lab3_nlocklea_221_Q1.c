/*
 * Nicholas Locklear G01090642
 * CS 262, Lab Section 221
 * Lab 3 Q1
 */

#include <stdio.h>

int main(){
	int variable;
	for(variable = 2; variable < 20; variable += 2){
		printf("value of variable: %d\n", variable);
	}
	return 0;
}