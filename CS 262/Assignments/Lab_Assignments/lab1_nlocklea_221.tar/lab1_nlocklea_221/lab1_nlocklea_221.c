/*
 * Nicholas Locklear G01090642
 * CS 262, Lab Section 221
 * Lab 1
 */
#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("My name is Nicholas\n");
    return 0;
}