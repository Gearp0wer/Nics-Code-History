/* Nicholas Locklear G01090642
 * CS 262 - 211
 * Lab 11 Function 2
 */

#include <stdio.h>
#include <stdlib.h>
#ifndef FUNCTION2_H
#define FUNCTION2_H

void Function2();

#endif