/* Nicholas Locklear G01090642
 * CS 262 - 211
 * Lab 11 Function 4
 */

#include <stdio.h>
#include <stdlib.h>
#ifndef FUNCTION4_H
#define FUNCTION4_H

void Function4();

#endif