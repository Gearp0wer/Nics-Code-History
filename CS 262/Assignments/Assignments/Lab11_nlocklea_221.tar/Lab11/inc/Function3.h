/* Nicholas Locklear G01090642
 * CS 262 - 211
 * Lab 11 Function 3
 */

#include <stdio.h>
#include <stdlib.h>
#ifndef FUNCTION3_H
#define FUNCTION3_H

void Function3();

#endif