# server_maintenance
Server Maintenance Logs for the One-Ten'ers Company.
Please refer to your on-boarding worksheet for how to perform your analysis on these logs.

//This repository contains the necessary files to support the Fall 2018 sections of the CS110 course at George Mason University.
