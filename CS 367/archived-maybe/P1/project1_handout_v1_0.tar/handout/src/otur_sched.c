/* This is the only file you will be editing.
 * - otur_sched.c (Otur Scheduler Library Code)
 * - Copyright of Starter Code: Prof. Kevin Andrea, George Mason University. All Rights Reserved
 * - Copyright of Student Code: You!  
 * - Copyright of ASCII Art: Modified from Joan Stark (jgs)'s work:
 * -- https://www.asciiart.eu/animals/other-water
 * - Restrictions on Student Code: Do not post your code on any public site (eg. Github).
 * -- Feel free to post your code on a PRIVATE Github and give interviewers access to it.
 * -- You are liable for the protection of your code from others.
 * - Date: Aug 2024
 */

/* CS367 Project 1, Spring Semester, 2024
 * Fill in your Name, GNumber, and Section Number in the following comment fields
 * Name:
 * GNumber:
 * Section Number: CS367-00_             (Replace the _ with your section number)
 */

/* otur CPU Scheduling Library
  .-"""-.
 /      o\
|    o   0).-.
|       .-;(_/         .-.
 \     /  /)).-------._|  `\   ,
  '.  '  /((           `'-./ _/|
    \  .'  )    OTUR    .-.;`  /
     '.                 |  `\-'
       '._            -'    /
 jgs      ``""------`------`
*/
 
/* Standard Library Includes */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
/* Unix System Includes */
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <pthread.h>
#include <sched.h>
/* Local Includes */
#include "otur_sched.h"
#include "vm_support.h"
#include "vm_process.h"

/* Feel free to create any helper functions you like! */

/*** Otur Library API Functions to Complete ***/

/* Initializes the Otur_schedule_s Struct and all of the Otur_queue_s Structs
 * Follow the project documentation for this function.
 * Returns a pointer to the new Otur_schedule_s or NULL on any error.
 * - Hint: What does malloc return on an error?
 */
Otur_schedule_s *otur_initialize() {
  return NULL; // Replace With Your Code
}

/* Allocate and Initialize a new Otur_process_s with the given information.
 * - Malloc and copy the command string, don't just assign it!
 * Follow the project documentation for this function.
 * - You may assume all arguments are Legal and Correct for this Function Only
 * Returns a pointer to the Otur_process_s on success or a NULL on any error.
 */
Otur_process_s *otur_invoke(pid_t pid, int is_high, int is_critical, char *command) {
  return NULL; // Replace With Your Code
}

/* Inserts a process into the appropriate Ready Queue (singly linked lists).
 * Follow the project documentation for this function.
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Returns a 0 on success or a -1 on any error.
 */
int otur_enqueue(Otur_schedule_s *schedule, Otur_process_s *process) {
  return -1; // Replace With Your Code
}

/* Returns the number of items in a given Otur Queue (singly linked list).
 * Follow the project documentation for this function.
 * Returns the number of processes in the list or -1 on any errors.
 */
int otur_count(Otur_queue_s *queue) {
  return -1; // Replace With Your Code
}

/* Selects the best process to run from the Ready Queue (singly linked list).
 * Follow the project documentation for this function.
 * Returns a pointer to the process selected or NULL if none available or on any errors.
 * - Do not create a new process to return, return a pointer to the SAME process selected.
 */
Otur_process_s *otur_select(Otur_schedule_s *schedule) {
  return NULL; // Replace With Your Code
}

/* Ages up all Process nodes in the Ready Queue - Normal and Promotes any that are Starving.
 * - If the Ready Queue - Normal is empty, return 0.  (Nothing to do, so it was a success)
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int otur_promote(Otur_schedule_s *schedule) {
  return -1; // Replace With Your Code
}

/* This is called when a process exits normally that was just Running.
 * Put the given node into the Defunct Queue and set the Exit Code into its state
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int otur_exited(Otur_schedule_s *schedule, Otur_process_s *process, int exit_code) {
  return -1; // Replace With Your Code
}

/* This is called when StrawHat kills a process early (kill command). 
 * - The Process will either be in your Ready or Suspended Queue, or neither.
 * - The difference with otur_exited is that this process is in one of your Queues already.
 * Remove the process with matching pid from the Ready or Suspended Queue and add the Exit Code to it.
 * - You have to check both since it could be in either queue.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error (eg. process not found).
 */
int otur_killed(Otur_schedule_s *schedule, pid_t pid, int exit_code) {
  return -1; // Replace With Your Code
}

/* This is called when the StrawHat reaps a Defunct process. (reap command)
 * Remove and free the process with matching pid from the Defunct Queue and return its exit code.
 * Follow the project documentation for this function.
 * Returns the process' exit code on success or a -1 if no such process or on any error.
 */
int otur_reap(Otur_schedule_s *schedule, pid_t pid) {
  return -1;
}

/* Frees all allocated memory in the Otur_schedule_s, all of the Queues, and all of their Nodes.
 * Follow the project documentation for this function.
 * Returns void.
 */
void otur_cleanup(Otur_schedule_s *schedule) {
  return; // Replace With Your Code
}
