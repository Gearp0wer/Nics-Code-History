/* This is the only file you will be editing.
 * - Copyright of Starter Code: Prof. Kevin Andrea, George Mason University.  All Rights Reserved
 * - Copyright of Student Code: You!  
 * - Restrictions on Student Code: Do not post your code on any public site (eg. Github).
 * -- Feel free to post your code on a PRIVATE Github and give interviewers access to it.
 * -- You are liable for the protection of your code from others.
 * - ASCII Art Adapted from Regular Calculator by Jeremy J. Olson
 * -- Original File: https://www.asciiart.eu/electronics/calculators
 * - Date: Feb 2024
 */

/* CS367 Project 2, Spring Semester, 2024
 * Fill in your Name, GNumber, and Section Number in the following comment fields
 * Name:
 * GNumber:
 * Section Number: CS367-00_             (Replace the _ with your section number)
 */

/* _____________________
  |  _________________  |
  | |     MUAN    3.25| |
  | |_________________| |
  |  ___ ___ ___   ___  |
  | | 7 | 8 | 9 | | + | |
  | |___|___|___| |___| |
  | | 4 | 5 | 6 | | - | |
  | |___|___|___| |___| |
  | | 1 | 2 | 3 | | x | |
  | |___|___|___| |___| |
  | | . | 0 | = | | V | |
  | |___|___|___| |___| |
  |_____________________|
 */

#include <stdio.h>
#include <stdlib.h>
#include "common_structs.h"
#include "common_definitions.h"
#include "common_functions.h"
#include "tinysf.h"

// Feel free to add many Helper Functions, Consts, and Definitions!

// ----------Public API Functions (write these!)-------------------

/* toTinySF - Converts a Number Struct (whole and fraction parts) into a TinySF Value
 *  - number is managed by MUAN, DO NOT FREE number.
 *    - You may change the contents of number, but do not free it.
 *  - Follow the project documentation for this function.
 * Return the TinySF Value or any legal TinySF NaN representation if number is NULL.
 */
tinysf_s toTinySF(Number_s *number) {
  return 0; // Replace this Line with your Code! 
}

/* toNumber - Converts a TinySF Value into a Number Struct (whole and fraction parts)
 *  - number is managed by MUAN, DO NOT FREE or re-Allocate number.
 *    - It is already allocated.  Do not call malloc/calloc for number.
 *  - Follow the project documentation for this function.
 *  If the conversion is successful, return 0. 
 *  - If number is NULL or there are any inconsistencies, return -1.
 */
int toNumber(Number_s *number, tinysf_s value) {
  return -1; // Replace this Line with your Code!
}

/* mulTinySF - Performs an operation on two tinySF values
 *  - Follow the project documentation for this function.
 * Return the resulting tinysf_s value
 */
tinysf_s mulTinySF(tinysf_s val1, tinysf_s val2) {
  return 0; // Replace this Line with your Code!
}

/* addTinySF - Performs an operation on two tinySF values
 *  - Follow the project documentation for this function.
 * Return the resulting tinysf_s value
 */
tinysf_s addTinySF(tinysf_s val1, tinysf_s val2) {
  return 0; // Replace this Line with your Code!
}

/* opTinySF - Performs an operation on two tinySF values
 *  - Follow the project documentation for this function.
 * Return the resulting tinysf_s value
 */
tinysf_s subTinySF(tinysf_s val1, tinysf_s val2) {
  return 0; // Replace this Line with your Code!
}

/* negTinySF - Negates a TinySF Value.
 *  - Follow the project documentation for this function.
 * Return the resulting TinySF Value
 */
tinysf_s negTinySF(tinysf_s value) {
  return 0; // Replace this Line with your Code!
}
